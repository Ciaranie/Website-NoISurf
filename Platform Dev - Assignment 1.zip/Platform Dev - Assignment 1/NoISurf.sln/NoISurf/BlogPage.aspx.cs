﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.OleDb;

namespace NoISurf
{
    public partial class BlogPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //Set up virtual database
                DataSet ds = new DataSet();
                //Read xml file
                ds.ReadXml(Server.MapPath("BlogFiles\\HitCounter.xml"));

                int hits = Convert.ToInt32(ds.Tables[0].Rows[0]["hitsBlog"]);

                hits++;
                lblCounter.Text = "This page has been visited " + hits.ToString() + " times.";

                //update the virtual database
                ds.Tables[0].Rows[0]["hitsBlog"] = hits.ToString();
                //write back to xml file
                ds.WriteXml(Server.MapPath("BlogFiles\\HitCounter.xml"));
            }
            loadBlog();
        }
        protected void loadBlog()
        {
            txtBlog.Text = "";

            string[] lines = File.ReadAllLines(Server.MapPath("BlogFiles/BlogContents.txt"));

            foreach (string element in lines)
            {
                txtBlog.Text += element;
                txtBlog.Text += "\n";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtEntry.Text == "")
                return;

            txtBlog.Text = txtEntry.Text + "\n" + txtBlog.Text;

            File.WriteAllText(Server.MapPath("BlogFiles/BlogContents.txt"), txtBlog.Text);

            txtEntry.Text = "";
        }
    }
}