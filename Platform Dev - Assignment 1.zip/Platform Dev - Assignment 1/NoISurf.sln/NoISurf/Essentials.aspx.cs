﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NoISurf
{
    public partial class Essentials : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BoardTypeWS.SurfBoardHelp useWS = new BoardTypeWS.SurfBoardHelp();

            string type = ddlBoard.Text;
            string weight = ddlWeight.Text;
            string output = useWS.GetBoardType(type, weight);

            lblOutput.Text = output;
        }
    }
}