﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace NoISurf
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["myCookie"];

            if (cookie != null)
            {
                runAPI();
            }
            else
            {
                lblColour.Text = "No Cookie Exists";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            runAPI();
        }

        protected void runAPI()
        {
            HttpCookie objCookie = new HttpCookie("myCookie");

            objCookie["colour"] = ddlColour.SelectedValue;
            objCookie["DateTime"] = DateTime.Now.ToString();

            objCookie.Expires = DateTime.Now.Add(new TimeSpan(0, 0, 0, 20));

            Response.Cookies.Add(objCookie);

            if (Request.Cookies["myCookie"] != null)
            {
                switch (Request.Cookies["myCookie"]["colour"].ToString())
                {
                    case "Orange":
                        lblColour.BackColor = Color.Orange;
                        break;

                    case "Green":
                        lblColour.BackColor = Color.Green;
                        break;

                    case "Red":
                        lblColour.BackColor = Color.Red;
                        break;
                }


            }
            else
            {
                lblColour.Text = "No Cookie Exists";
            }
            lblDateTime.Text = "Last time you created a cookie was " + Request.Cookies["myCookie"]["DateTime"].ToString();

            lblColour.Text = "You have changed the colour to " + Request.Cookies["myCookie"]["colour"].ToString();
            form1.Style["background"] = Request.Cookies["myCookie"]["colour"].ToString();
        }
    }
}