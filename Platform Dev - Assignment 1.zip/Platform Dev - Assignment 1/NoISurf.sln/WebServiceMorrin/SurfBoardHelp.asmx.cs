﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebServiceMorrin
{
    /// <summary>
    /// Summary description for SurfBoardHelp
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class SurfBoardHelp : System.Web.Services.WebService
    {

        [WebMethod]
        public string GetBoardType(string type, string weight)
        {
            if (type == "Longboard" && weight == "Less than 63kg")
            {
                return "You should ride a Longboard that is 9'2' - 9'4'";
            }
            else if (type == "Longboard" && weight == "64kg - 90kg")
            {
                return "You should ride a Longboard that is  9'5' - 10'";
            }
            else if (type == "Longboard" && weight == "90kg+")
            {
                return "You should ride a Longboard that is +10'";
            }
            else if (type == "Shortboard" && weight == "Less than 63kg")
            {
                return "You should ride a Shortboard that is  6'2' - 6'4'";
            }
            else if (type == "Shortboard" && weight == "64kg - 90kg")
            {
                return "You should ride a Shortboard that is  6'5' - 7'";
            }
            else if (type == "Shortboard" && weight == "90kg+")
            {
                return "You should ride a Shortboard that is  +7'1'";
            }
            else if (type == "Fish board" && weight == "Less than 63kg")
            {
                return "You should ride a Fish board that is  6'1' - 6'4'";
            }
            else if (type == "Fish board" && weight == "64kg - 90kg")
            {
                return "You should ride a Fish board that is  6'5' - 7'4'";
            }
            else if (type == "Fish board" && weight == "90kg+")
            {
                return "You should ride a Fish board that is  +7'5";
            }
            else
            {
                return "";
            }
        }
    }
}
